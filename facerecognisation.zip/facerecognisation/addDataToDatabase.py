import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

# Load your Firebase service account key
cred = credentials.Certificate(r"C:\Users\arsfa\OneDrive\Desktop\projects\facerecognisation\FaceRecognition\serviceAccountKey.json")

# Correct key: 'databaseURL' (not 'dataBaseURL')
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://facerecognitionrealtime-5be87-default-rtdb.firebaseio.com/"
})

# Reference to 'Students' node
ref = db.reference('Students')

# Sample data
data = {
    "312654": {
        "name": "Ganga babu",
        "major": "Robotics",
        "starting_year": 2023,
        "total_attendance": 4,
        "standing": "Good",
        "year": 4,
        "last_attendance_time": "2022-4-17 00:10:51"
    },

    "852741": {
        "name": "Emly blunt",
        "major": "BCA",
        "starting_year": 2023,
        "total_attendance": 10,
        "standing": "very Good",
        "year": 3,
        "last_attendance_time": "2022-4-17 00:10:51"
    },

    "963852": {
        "name": "Alon Musk",
        "major": "Robotics",
        "starting_year": 2022,
        "total_attendance": 14,
        "standing": "Good",
        "year": 4,
        "last_attendance_time": "2022-4-17 00:10:51"
    }
}

# Upload the data to Firebase
for key, value in data.items():
    ref.child(key).set(value)
