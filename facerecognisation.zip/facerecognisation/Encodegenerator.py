import cv2
import face_recognition
import os
import pickle
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from supabase import create_client

cred = credentials.Certificate(r"C:\Users\arsfa\OneDrive\Desktop\projects\facerecognisation\FaceRecognition\serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://facerecognitionrealtime-5be87-default-rtdb.firebaseio.com/"
})

url = "https://bjsyjnjbthvfdmheogfk.supabase.co"
key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJqc3lqbmpidGh2ZmRtaGVvZ2ZrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDYwMjI5NTksImV4cCI6MjA2MTU5ODk1OX0.YXjhp2AY5Lwrb9pgPk4Egnjuk7VUd51hPde00jUAaXY"
supabase = create_client(url, key)
bucket = supabase.storage.from_("face-recognition-project")

folderPath = r'C:\Users\arsfa\OneDrive\Desktop\projects\facerecognisation\FaceRecognition\Images'
PathList = os.listdir(folderPath)
print("Image Files:", PathList)

imgList = []
studentsIds = []

for path in PathList:
    img_path = os.path.join(folderPath, path)
    imgList.append(cv2.imread(img_path))
    studentsIds.append(os.path.splitext(path)[0])

    with open(img_path, "rb") as file:
        bucket.upload(f"images/{path}", file)

print("Student IDs:", studentsIds)

def findEncodings(imagesList):
    encodeList = []
    for img in imagesList:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList

print('Encoding Started .....')
encodeListKnown = findEncodings(imgList)
encodeListKnownWithIds = [encodeListKnown, studentsIds]
print('Encoding Completed!')

file_path = "EncodeFile.p"
with open(file_path, 'wb') as file:
    pickle.dump(encodeListKnownWithIds, file)
print('File Saved Locally')

with open(file_path, "rb") as f:
    supabase_path = "encodings/EncodeFile.p"
    bucket.upload(supabase_path, f)

public_url = bucket.get_public_url(supabase_path)
print("Public URL of EncodeFile.p:", public_url)
